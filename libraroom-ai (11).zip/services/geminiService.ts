
import { GoogleGenAI } from "@google/genai";
import { User, Todo, Note } from "../types";

/**
 * Libraroom Neural Service
 * Optimized for Free Tier usage via process.env.API_KEY.
 */

// Safe helper to access environment variables in a browser context
const getApiKey = () => {
  try {
    // In many build environments (like Netlify), process.env might not be globally available
    // without explicit injection. We access it safely here.
    return (typeof process !== 'undefined' && process.env?.API_KEY) ? process.env.API_KEY : '';
  } catch (e) {
    return '';
  }
};

const getNeuralContext = () => {
  try {
    const userJson = localStorage.getItem('libraroom_user');
    const user: User | null = userJson ? JSON.parse(userJson) : null;
    const email = user?.email || '';
    
    const tasks: Todo[] = JSON.parse(localStorage.getItem(`libraroom_todos_${email}`) || '[]');
    const notes: Note[] = JSON.parse(localStorage.getItem(`libraroom_notes_${email}`) || '[]');
    
    const taskSummary = tasks.length > 0 
      ? tasks.slice(0, 5).map(t => `- [${t.completed ? 'x' : ' '}] ${t.text}`).join('\n')
      : 'No pending tasks.';
      
    const notesSummary = notes.length > 0
      ? notes.slice(0, 3).map(n => `- ${n.title}`).join('\n')
      : 'Empty vault.';

    return `CONTEXT:\nUser: ${user?.nickname || 'Scholar'}\nActive Agenda:\n${taskSummary}\nKnowledge Base:\n${notesSummary}`;
  } catch (e) {
    return 'CONTEXT: Initialization stage.';
  }
};

const getSystemInstruction = () => {
  const custom = localStorage.getItem('libraroom_ai_instruction') || '';
  const context = getNeuralContext();

  return `You are Libraroom AI, a high-efficiency academic processor.
PERSONA: Minimalist, sophisticated, ultra-direct.
${context}

STRICT CONSTRAINTS:
1. BREVITY: Max 2 sentences per response.
2. NO BOLDING: Never use ** or bold markdown.
3. NO FILLER: Skip introductions like "Hello" or "Sure".
4. FORMAT: Plain text or simple dashes (-).
${custom ? `\nUSER CUSTOMIZATION: ${custom}` : ''}`;
};

/**
 * Global AI Query Interface
 * Re-initializes on every call to ensure key freshness and session stability.
 */
export const queryAI = async (prompt: string): Promise<string> => {
  const apiKey = getApiKey();
  if (!apiKey) {
    return "Neural connection failed. Please ensure API_KEY is set in the environment variables.";
  }
  
  try {
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        systemInstruction: getSystemInstruction(),
        temperature: 0.5,
      },
    });

    const text = response.text || "The neural matrix is silent.";
    return text.replace(/\*\*/g, ''); 
  } catch (error: any) {
    console.error("Neural Error:", error);
    if (error.message?.includes("429")) return "System cooling down (Rate limit). Try again in 60s.";
    return `Neural link failed: ${error.message || "Unknown error"}`;
  }
};

export const polishNotes = (c: string) => queryAI(`Refine this academic draft for professional clarity. Plain text, NO BOLD:\n\n${c}`);
export const summarizeNotes = (c: string) => queryAI(`Synthesize into a 3-point summary. Use plain dashes, NO BOLD:\n\n${c}`);
export const brainstormIdeas = (t: string) => queryAI(`Generate 5 research angles for "${t}". Short, NO BOLD.`);

/**
 * Stateful Chat Session Manager
 */
export class GeminiChatSession {
  async sendMessage(params: { message: string }) {
    const apiKey = getApiKey();
    if (!apiKey) {
      return { text: "Neural connection error: API_KEY missing." };
    }

    try {
      // Re-initialize for every turn to satisfy safety and freshness requirements
      const ai = new GoogleGenAI({ apiKey });
      const chat = ai.chats.create({
        model: "gemini-3-flash-preview",
        config: {
          systemInstruction: getSystemInstruction(),
        },
      });
      const response = await chat.sendMessage({ message: params.message });
      const text = (response.text || "").replace(/\*\*/g, '');
      return { text };
    } catch (err: any) {
      console.error("Chat Session Error:", err);
      return { text: `Neural link interrupted: ${err.message || "Connection failure"}` };
    }
  }
}

export const createAIChatSession = () => new GeminiChatSession();


import { neon } from '@neondatabase/serverless';
import { User, Todo, Note, ChatMessage } from '../types';

/**
 * Libraroom AI Database Service
 * Powered by Neon (PostgreSQL)
 */

const getDatabaseUrl = () => {
  try {
    const url = process.env.DATABASE_URL;
    if (url && (url.startsWith('postgres://') || url.startsWith('postgresql://'))) {
      return url;
    }
  } catch (e) {
    console.warn("Neural Database: URL access error:", e);
  }
  return '';
};

const DATABASE_URL = getDatabaseUrl();

let sql: any = null;
if (DATABASE_URL) {
  try {
    sql = neon(DATABASE_URL);
    console.log("Neural Database: Bridge established.");
    
    setTimeout(async () => {
      try {
        await sql`
          CREATE TABLE IF NOT EXISTS users (
            email TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            nickname TEXT NOT NULL,
            password TEXT NOT NULL
          );
        `;
        await sql`
          CREATE TABLE IF NOT EXISTS tasks (
            id TEXT PRIMARY KEY,
            user_email TEXT REFERENCES users(email) ON DELETE CASCADE,
            text TEXT NOT NULL,
            completed BOOLEAN DEFAULT FALSE,
            created_at BIGINT NOT NULL
          );
        `;
        await sql`
          CREATE TABLE IF NOT EXISTS notes (
            id TEXT PRIMARY KEY,
            user_email TEXT REFERENCES users(email) ON DELETE CASCADE,
            title TEXT NOT NULL,
            content TEXT,
            updated_at BIGINT NOT NULL
          );
        `;
        await sql`
          CREATE TABLE IF NOT EXISTS chat_messages (
            id TEXT PRIMARY KEY,
            user_email TEXT REFERENCES users(email) ON DELETE CASCADE,
            role TEXT NOT NULL,
            text TEXT NOT NULL,
            created_at BIGINT NOT NULL
          );
        `;
        console.log("Neural Database: Tables synchronized.");
      } catch (err) {
        console.error("Neural Database: Handshake failed.", err);
      }
    }, 1000);
  } catch (err) {
    console.error("Neural Database: Connection failed", err);
  }
}

export const isCloudConnected = () => !!sql;

export const dbService = {
  async signup(user: User): Promise<boolean> {
    if (!sql) {
      const users = JSON.parse(localStorage.getItem('libraroom_users_db') || '[]');
      if (users.find((u: any) => u.email === user.email)) return false;
      users.push(user);
      localStorage.setItem('libraroom_users_db', JSON.stringify(users));
      return true;
    }
    try {
      await sql`INSERT INTO users (email, name, nickname, password) VALUES (${user.email}, ${user.name}, ${user.nickname}, ${user.password}) ON CONFLICT (email) DO NOTHING`;
      return true;
    } catch (e) { return false; }
  },

  async login(email: string, password?: string): Promise<User | null> {
    if (!sql) {
      const users = JSON.parse(localStorage.getItem('libraroom_users_db') || '[]');
      return users.find((u: any) => u.email === email && u.password === password) || null;
    }
    try {
      const result = await sql`SELECT email, name, nickname FROM users WHERE email = ${email} AND password = ${password} LIMIT 1`;
      return result[0] ? (result[0] as User) : null;
    } catch (e) { return null; }
  },

  async saveTasks(email: string, todos: Todo[]) {
    if (!sql) return;
    try {
      for (const todo of todos) {
        await sql`INSERT INTO tasks (id, user_email, text, completed, created_at) VALUES (${todo.id}, ${email}, ${todo.text}, ${todo.completed}, ${todo.createdAt}) ON CONFLICT (id) DO UPDATE SET text = EXCLUDED.text, completed = EXCLUDED.completed`;
      }
      const ids = todos.map(t => t.id);
      if (ids.length > 0) await sql`DELETE FROM tasks WHERE user_email = ${email} AND NOT (id = ANY(${ids}))`;
      else await sql`DELETE FROM tasks WHERE user_email = ${email}`;
    } catch (e) {}
  },

  async getTasks(email: string): Promise<Todo[]> {
    if (!sql) return JSON.parse(localStorage.getItem(`libraroom_todos_${email}`) || '[]');
    try {
      const result = await sql`SELECT id, text, completed, created_at as "createdAt" FROM tasks WHERE user_email = ${email} ORDER BY created_at DESC`;
      return result as unknown as Todo[];
    } catch (e) { return JSON.parse(localStorage.getItem(`libraroom_todos_${email}`) || '[]'); }
  },

  async saveNotes(email: string, notes: Note[]) {
    if (!sql) return;
    try {
      for (const note of notes) {
        await sql`INSERT INTO notes (id, user_email, title, content, updated_at) VALUES (${note.id}, ${email}, ${note.title}, ${note.content}, ${note.updatedAt}) ON CONFLICT (id) DO UPDATE SET title = EXCLUDED.title, content = EXCLUDED.content, updated_at = EXCLUDED.updated_at`;
      }
      const ids = notes.map(n => n.id);
      if (ids.length > 0) await sql`DELETE FROM notes WHERE user_email = ${email} AND NOT (id = ANY(${ids}))`;
      else await sql`DELETE FROM notes WHERE user_email = ${email}`;
    } catch (e) {}
  },

  async getNotes(email: string): Promise<Note[]> {
    if (!sql) return JSON.parse(localStorage.getItem(`libraroom_notes_${email}`) || '[]');
    try {
      const result = await sql`SELECT id, title, content, updated_at as "updatedAt" FROM notes WHERE user_email = ${email} ORDER BY updated_at DESC`;
      return result as unknown as Note[];
    } catch (e) { return JSON.parse(localStorage.getItem(`libraroom_notes_${email}`) || '[]'); }
  },

  async saveChatMessages(email: string, messages: ChatMessage[]) {
    if (!sql) return;
    try {
      // Chat history can grow large, we only sync the last 100 messages for efficiency
      const recentMessages = messages.slice(-100);
      for (const msg of recentMessages) {
        await sql`
          INSERT INTO chat_messages (id, user_email, role, text, created_at)
          VALUES (${msg.id}, ${email}, ${msg.role}, ${msg.text}, ${msg.createdAt})
          ON CONFLICT (id) DO NOTHING
        `;
      }
    } catch (e) { console.error('DB Chat Sync Error:', e); }
  },

  async getChatMessages(email: string): Promise<ChatMessage[]> {
    if (!sql) return JSON.parse(localStorage.getItem(`libraroom_chats_${email}`) || '[]');
    try {
      const result = await sql`
        SELECT id, role, text, created_at as "createdAt"
        FROM chat_messages
        WHERE user_email = ${email}
        ORDER BY created_at ASC
      `;
      return result as unknown as ChatMessage[];
    } catch (e) {
      return JSON.parse(localStorage.getItem(`libraroom_chats_${email}`) || '[]');
    }
  }
};

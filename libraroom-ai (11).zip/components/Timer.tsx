import React, { useState, useEffect, useRef } from 'react';

export const Timer: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [totalTime, setTotalTime] = useState(25 * 60);
  const [isActive, setIsActive] = useState(false);
  const [showCustomInput, setShowCustomInput] = useState(false);
  const [customMinutes, setCustomMinutes] = useState('');
  const timerRef = useRef<number | null>(null);

  // Reduced radius for a more compact, modern feel
  const radius = 95;
  const circumference = 2 * Math.PI * radius;
  const progress = totalTime > 0 ? (timeLeft / totalTime) : 0;
  const strokeDashoffset = circumference * (1 - progress);

  useEffect(() => {
    if (isActive) {
      timerRef.current = window.setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            setIsActive(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [isActive]);

  const setPreset = (mins: number) => {
    setIsActive(false);
    setShowCustomInput(false);
    const seconds = mins * 60;
    setTimeLeft(seconds);
    setTotalTime(seconds);
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const mins = parseInt(customMinutes);
    if (!isNaN(mins) && mins > 0 && mins <= 999) {
      setPreset(mins);
      setCustomMinutes('');
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const presets = [25, 45, 60];

  return (
    <div className="flex flex-col items-center justify-center animate-in zoom-in duration-700 w-full py-4">
      
      {/* Visual Timer Display - Reduced Max Width */}
      <div className="relative w-full max-w-[340px] aspect-square flex items-center justify-center mb-8">
        {/* Scaled down glow */}
        <div className={`absolute w-56 h-56 rounded-full blur-[80px] transition-all duration-1000 ${isActive ? 'bg-indigo-500/20' : 'bg-slate-800/10'}`} />
        
        <svg className="absolute w-full h-full -rotate-90" viewBox="0 0 300 300">
          <circle cx="150" cy="150" r={radius} stroke="currentColor" strokeWidth="5" fill="transparent" className="text-white/5" />
          <circle
            cx="150"
            cy="150"
            r={radius}
            stroke="currentColor"
            strokeWidth="6"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            fill="transparent"
            className={`transition-all duration-1000 ease-out ${isActive ? 'animate-neon' : ''} text-indigo-500`}
          />
        </svg>

        <div className="relative text-center">
          {/* Refined font size for the ring proportion */}
          <span className="text-6xl sm:text-7xl font-light font-['JetBrains_Mono'] tracking-tighter tabular-nums text-white neon-text-indigo transition-all duration-700 whitespace-nowrap">
            {formatTime(timeLeft)}
          </span>
          <p className="mt-2 text-[9px] font-bold text-slate-500 uppercase tracking-[0.4em] whitespace-nowrap">
            {isActive ? 'Neural Flow Active' : 'System Ready'}
          </p>
        </div>
      </div>

      {/* Preset Controls - Tighter Spacing */}
      <div className="flex flex-wrap justify-center gap-2.5 mb-8">
        {presets.map(min => (
          <button
            key={min}
            onClick={() => setPreset(min)}
            className={`w-11 h-11 rounded-xl flex items-center justify-center text-[10px] font-bold border transition-all whitespace-nowrap ${
              totalTime === min * 60 && !showCustomInput
              ? 'bg-indigo-600/20 border-indigo-500/40 text-indigo-400 shadow-lg' 
              : 'bg-white/5 border-white/5 text-slate-500 hover:text-white hover:border-white/10'
            }`}
          >
            {min}m
          </button>
        ))}
        
        <button
          onClick={() => setShowCustomInput(!showCustomInput)}
          className={`px-4 h-11 rounded-xl flex items-center justify-center text-[9px] font-bold uppercase tracking-widest border transition-all whitespace-nowrap ${
            showCustomInput 
            ? 'bg-indigo-600/20 border-indigo-500/40 text-indigo-400' 
            : 'bg-white/5 border-white/5 text-slate-500 hover:text-white'
          }`}
        >
          {showCustomInput ? 'Cancel' : 'Custom'}
        </button>
      </div>

      {/* Custom Duration Form */}
      {showCustomInput && (
        <form onSubmit={handleCustomSubmit} className="mb-8 animate-in slide-in-from-top-4 fade-in duration-300">
          <div className="flex items-center gap-2 p-1 bg-slate-950/40 rounded-xl border border-white/5">
            <input
              type="number"
              value={customMinutes}
              onChange={(e) => setCustomMinutes(e.target.value)}
              placeholder="Min"
              min="1"
              max="999"
              className="w-16 bg-transparent border-none text-center text-sm text-white font-bold placeholder:text-slate-800 focus:ring-0"
              autoFocus
            />
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-[10px] font-bold uppercase tracking-widest hover:bg-indigo-500 transition-all"
            >
              Set
            </button>
          </div>
        </form>
      )}

      {/* Primary Action Buttons */}
      <div className="flex items-center gap-4">
        <button
          onClick={() => setIsActive(!isActive)}
          className={`group relative h-12 px-8 rounded-2xl font-bold text-[10px] tracking-[0.2em] uppercase transition-all duration-300 flex items-center gap-2.5 overflow-hidden ${
            isActive 
              ? 'bg-slate-900 text-slate-400 border border-white/5 hover:text-white hover:border-white/10' 
              : 'bg-indigo-600 text-white hover:bg-indigo-500 shadow-xl shadow-indigo-600/20'
          }`}
        >
          <div className="relative z-10 flex items-center gap-2">
            {isActive ? (
              <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" /></svg>
            ) : (
              <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" /></svg>
            )}
            <span>{isActive ? 'Pause' : 'Start Flow'}</span>
          </div>
          {!isActive && <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />}
        </button>

        <button
          onClick={() => { setIsActive(false); setTimeLeft(totalTime); }}
          className="w-12 h-12 rounded-2xl bg-slate-900/60 border border-white/5 text-slate-500 hover:text-rose-400 hover:bg-rose-500/5 transition-all flex items-center justify-center"
          title="Reset Timer"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
        </button>
      </div>
    </div>
  );
};

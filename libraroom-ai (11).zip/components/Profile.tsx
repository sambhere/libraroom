import React from 'react';
import { User } from '../types';

interface ProfileProps {
  user: User;
  onLogout: () => void;
  onBack: () => void;
}

export const Profile: React.FC<ProfileProps> = ({ user, onLogout, onBack }) => {
  return (
    <div className="flex flex-col items-center max-w-2xl mx-auto py-4 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Profile Header Card */}
      <div className="w-full dashboard-card rounded-[3rem] p-8 sm:p-12 border-white/5 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-600/10 blur-[100px] -mr-32 -mt-32 rounded-full" />
        
        <div className="relative flex flex-col items-center">
          {/* Large Avatar */}
          <div className="relative mb-8">
            <div className="absolute -inset-4 bg-gradient-to-tr from-indigo-500/20 to-purple-500/20 rounded-full blur-xl animate-pulse" />
            <div className="relative w-32 h-32 rounded-full border-4 border-indigo-500/30 p-1 bg-[#020617]">
              <img 
                src={`https://api.dicebear.com/7.x/bottts/svg?seed=${user.email}`} 
                className="w-full h-full rounded-full object-cover bg-slate-800 shadow-inner" 
                alt="Neural Avatar" 
              />
            </div>
            <div className="absolute bottom-1 right-1 w-8 h-8 bg-emerald-500 border-4 border-[#020617] rounded-full shadow-lg" />
          </div>

          <h2 className="text-3xl font-extrabold text-white tracking-tight mb-2">Neural Profile</h2>
          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.4em] mb-12">User Identification Verified</p>

          {/* Identity Grid */}
          <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-4 mb-12">
            <div className="bg-white/5 border border-white/5 rounded-2xl p-5 group hover:border-indigo-500/30 transition-all">
              <p className="text-[9px] font-bold text-slate-600 uppercase tracking-widest mb-1 group-hover:text-indigo-400 transition-colors">Legal Name</p>
              <p className="text-sm font-semibold text-slate-200">{user.name}</p>
            </div>
            <div className="bg-white/5 border border-white/5 rounded-2xl p-5 group hover:border-indigo-500/30 transition-all">
              <p className="text-[9px] font-bold text-slate-600 uppercase tracking-widest mb-1 group-hover:text-indigo-400 transition-colors">AI Nickname</p>
              <p className="text-sm font-semibold text-indigo-400">{user.nickname}</p>
            </div>
            <div className="bg-white/5 border border-white/5 rounded-2xl p-5 sm:col-span-2 group hover:border-indigo-500/30 transition-all">
              <p className="text-[9px] font-bold text-slate-600 uppercase tracking-widest mb-1 group-hover:text-indigo-400 transition-colors">Access Email</p>
              <p className="text-sm font-semibold text-slate-200">{user.email}</p>
            </div>
          </div>

          {/* Actions */}
          <div className="w-full flex flex-col sm:flex-row gap-4">
            <button
              onClick={onBack}
              className="flex-1 py-4 rounded-2xl bg-indigo-600 text-white text-[11px] font-bold uppercase tracking-widest shadow-xl shadow-indigo-600/20 hover:bg-indigo-500 transition-all"
            >
              Return to Focus
            </button>
            <button
              onClick={onLogout}
              className="px-8 py-4 rounded-2xl bg-white/5 border border-white/5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/5 transition-all text-[11px] font-bold uppercase tracking-widest"
            >
              Sign Out
            </button>
          </div>
        </div>
      </div>

      {/* Stats Footer */}
      <div className="w-full grid grid-cols-3 gap-4 mt-6">
        {[
          { label: 'Streak', value: '7 Days', color: 'text-orange-400' },
          { label: 'Rank', value: 'Scholar', color: 'text-indigo-400' },
          { label: 'Efficiency', value: '94%', color: 'text-emerald-400' }
        ].map((stat, i) => (
          <div key={i} className="bg-slate-900/40 border border-white/5 rounded-2xl p-4 text-center">
            <p className="text-[8px] font-bold text-slate-600 uppercase tracking-tighter mb-1">{stat.label}</p>
            <p className={`text-xs font-bold ${stat.color}`}>{stat.value}</p>
          </div>
        ))}
      </div>
    </div>
  );
};
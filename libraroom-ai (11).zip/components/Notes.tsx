
import React, { useState, useEffect } from 'react';
import { Note } from '../types';
import { polishNotes, summarizeNotes, brainstormIdeas } from '../services/geminiService';
import { dbService } from '../services/databaseService';

interface NotesProps {
  userEmail: string;
}

export const Notes: React.FC<NotesProps> = ({ userEmail }) => {
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeNoteId, setActiveNoteId] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);

  // Initial Load
  useEffect(() => {
    const loadNotes = async () => {
      setLoading(true);
      const data = await dbService.getNotes(userEmail);
      if (data.length === 0) {
        const defaultNote = { id: Date.now().toString(), title: 'Getting Started', content: 'Welcome to your Neural Study Vault. Start typing here...', updatedAt: Date.now() };
        setNotes([defaultNote]);
        setActiveNoteId(defaultNote.id);
      } else {
        setNotes(data);
        setActiveNoteId(data[0].id);
      }
      setLoading(false);
    };
    loadNotes();
  }, [userEmail]);

  // Debounced Sync to Cloud
  useEffect(() => {
    if (loading) return;
    localStorage.setItem(`libraroom_notes_${userEmail}`, JSON.stringify(notes));
    const timeout = setTimeout(() => {
      if (notes.length > 0) {
        dbService.saveNotes(userEmail, notes);
      }
    }, 1000);
    return () => clearTimeout(timeout);
  }, [notes, userEmail, loading]);

  const activeNote = notes.find(n => n.id === activeNoteId) || notes[0];

  const updateContent = (content: string) => {
    setNotes(notes.map(n => n.id === activeNoteId ? { ...n, content, updatedAt: Date.now() } : n));
  };

  const updateTitle = (title: string) => {
    setNotes(notes.map(n => n.id === activeNoteId ? { ...n, title, updatedAt: Date.now() } : n));
  };

  const handleAction = async (action: 'polish' | 'summarize' | 'brainstorm') => {
    if (!activeNote?.content.trim() && action !== 'brainstorm') return;
    
    setIsProcessing(true);
    try {
      let result = "";
      if (action === 'polish') result = await polishNotes(activeNote.content);
      else if (action === 'summarize') result = await summarizeNotes(activeNote.content);
      else if (action === 'brainstorm') {
        const topic = prompt("What topic should I brainstorm ideas for?") || "";
        if (!topic.trim()) {
          setIsProcessing(false);
          return;
        }
        result = await brainstormIdeas(topic);
      }
      
      if (result === "NEURAL_LINK_MISSING") {
        alert("The site administrator hasn't configured the Neural Bridge yet. Please try again later!");
        return;
      }

      if (action === 'summarize' || action === 'brainstorm') {
        updateContent(`### Neural ${action === 'summarize' ? 'Summary' : 'Ideas'}\n${result}\n\n---\n\n${activeNote.content}`);
      } else {
        updateContent(result);
      }
    } catch (e) {
      console.error(e);
      alert("I encountered a neural glitch. Please check your connection and try again!");
    } finally {
      setIsProcessing(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-full py-20 animate-pulse">
        <div className="w-12 h-12 bg-indigo-500/20 rounded-2xl mb-4" />
        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Opening Secure Vault...</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-3 overflow-x-auto pb-2 scrollbar-hide">
          {notes.map(n => (
            <button
              key={n.id}
              onClick={() => setActiveNoteId(n.id)}
              className={`px-6 py-3 rounded-2xl text-[12px] font-bold tracking-wide transition-all border whitespace-nowrap ${
                activeNoteId === n.id ? 'bg-indigo-500/10 border-indigo-500/30 text-indigo-400' : 'bg-white/5 border-white/5 text-slate-500 hover:text-slate-300'
              }`}
            >
              {n.title || 'Untitled Archive'}
            </button>
          ))}
          <button 
            onClick={() => {
              const newNote = { id: Date.now().toString(), title: 'New Document', content: '', updatedAt: Date.now() };
              setNotes([newNote, ...notes]);
              setActiveNoteId(newNote.id);
            }}
            className="w-11 h-11 flex-shrink-0 flex items-center justify-center rounded-2xl bg-white/5 text-slate-500 hover:text-white transition-all hover:bg-indigo-600/20"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 4v16m8-8H4" /></svg>
          </button>
        </div>

        <div className="hidden lg:flex gap-3">
           <button onClick={() => handleAction('brainstorm')} disabled={isProcessing} className="px-6 h-11 rounded-2xl bg-white/5 border border-white/10 text-[11px] font-bold uppercase tracking-widest text-slate-400 hover:text-white transition-all disabled:opacity-30">
              Brainstorm
           </button>
           <button onClick={() => handleAction('polish')} disabled={isProcessing || !activeNote?.content} className="px-6 h-11 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-[11px] font-bold uppercase tracking-widest text-indigo-400 hover:bg-indigo-500/20 transition-all disabled:opacity-30">
              Refine Draft
           </button>
           <button onClick={() => handleAction('summarize')} disabled={isProcessing || !activeNote?.content} className="px-6 h-11 rounded-2xl bg-indigo-600 text-[11px] font-bold uppercase tracking-widest text-white hover:bg-indigo-500 transition-all shadow-xl shadow-indigo-600/20 disabled:opacity-30">
              Synthesize AI
           </button>
        </div>
      </div>

      {activeNote && (
        <div className="flex-1 flex flex-col bg-slate-900/40 rounded-[2.5rem] border border-white/5 p-8 sm:p-12 lg:p-16 min-h-[600px] shadow-2xl backdrop-blur-3xl overflow-hidden relative">
          {isProcessing && (
            <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm z-50 flex items-center justify-center rounded-[2.5rem]">
              <div className="flex flex-col items-center gap-4">
                <div className="w-10 h-10 border-4 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin" />
                <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest">AI Brainstorming...</p>
              </div>
            </div>
          )}
          
          <input
            type="text"
            value={activeNote.title}
            onChange={(e) => updateTitle(e.target.value)}
            className="bg-transparent border-none text-3xl sm:text-4xl font-extrabold text-white focus:ring-0 placeholder:text-slate-800 transition-all mb-8 p-0 tracking-tight"
            placeholder="Document Title..."
          />

          <textarea
            value={activeNote.content}
            onChange={(e) => updateContent(e.target.value)}
            placeholder="Start your intellectual journey here..."
            className="flex-1 bg-transparent border-none p-0 text-lg leading-[1.8] text-slate-300 resize-none focus:ring-0 placeholder:text-slate-800 font-serif overflow-y-auto custom-scrollbar"
          />
          
          <div className="lg:hidden mt-8 grid grid-cols-2 gap-4">
            <button onClick={() => handleAction('brainstorm')} disabled={isProcessing} className="h-14 rounded-2xl bg-white/5 text-[10px] font-bold uppercase tracking-widest">Brainstorm</button>
            <button onClick={() => handleAction('summarize')} disabled={isProcessing || !activeNote?.content} className="h-14 rounded-2xl bg-indigo-600 text-[10px] font-bold uppercase tracking-widest disabled:opacity-30">Synthesize</button>
          </div>
        </div>
      )}
    </div>
  );
};


import React, { useState } from 'react';
import { User } from '../types';
import { dbService } from '../services/databaseService';

interface AuthProps {
  onLogin: (user: User) => void;
  onBack: () => void;
}

export const Auth: React.FC<AuthProps> = ({ onLogin, onBack }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    name: '',
    nickname: '',
    password: ''
  });
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (isLogin) {
        const user = await dbService.login(formData.email, formData.password);
        if (user) {
          onLogin(user);
        } else {
          setError('Invalid credentials. Check your link! 🔗');
        }
      } else {
        if (!formData.email || !formData.password || !formData.name || !formData.nickname) {
          setError('All fields are required, bestie! ✨');
          setLoading(false);
          return;
        }
        
        const newUser: User = {
          email: formData.email,
          name: formData.name,
          nickname: formData.nickname,
          password: formData.password
        };

        const success = await dbService.signup(newUser);
        if (success) {
          onLogin(newUser);
        } else {
          setError('Email already registered in Neural Cloud ☁️');
        }
      }
    } catch (err) {
      setError('System connection failure. Try again later.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-[#020617]">
      <div className="absolute inset-0 bg-animate opacity-50"></div>
      
      {/* Back Button */}
      <button 
        onClick={onBack}
        className="absolute top-8 left-8 p-3 rounded-full bg-white/5 border border-white/10 text-slate-400 hover:text-white hover:bg-white/10 hover:border-white/20 transition-all z-[110] group"
        aria-label="Back to landing page"
      >
        <svg className="w-5 h-5 transition-transform group-hover:-translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
        </svg>
      </button>

      <div className="relative w-full max-w-md animate-in zoom-in duration-500">
        <div className="dashboard-card rounded-[2.5rem] p-8 sm:p-12 backdrop-blur-3xl border-white/5 shadow-2xl">
          <div className="flex flex-col items-center mb-10">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-indigo-600 to-violet-600 flex items-center justify-center shadow-2xl shadow-indigo-500/40 mb-6 rotate-12 group-hover:rotate-0 transition-transform">
              <span className="font-bold text-white text-3xl italic tracking-tighter">L</span>
            </div>
            <h1 className="text-2xl font-bold text-white tracking-tight mb-2 text-center">
              {isLogin ? 'Welcome back to Libraroom AI' : 'Join Libraroom AI'}
            </h1>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.2em] text-center">
              {isLogin ? 'Initializing Database Handshake' : 'Secure Neural Cloud Registration'}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <>
                <input
                  type="text"
                  placeholder="Full Name"
                  className="w-full bg-white/5 border border-white/5 rounded-2xl px-6 py-4 text-sm text-white focus:outline-none focus:border-indigo-500/50 transition-all placeholder:text-slate-700"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  disabled={loading}
                />
                <input
                  type="text"
                  placeholder="Nickname (AI calls you this)"
                  className="w-full bg-white/5 border border-white/5 rounded-2xl px-6 py-4 text-sm text-white focus:outline-none focus:border-indigo-500/50 transition-all placeholder:text-slate-700"
                  value={formData.nickname}
                  onChange={(e) => setFormData({...formData, nickname: e.target.value})}
                  disabled={loading}
                />
              </>
            )}
            <input
              type="email"
              placeholder="Email Address"
              className="w-full bg-white/5 border border-white/5 rounded-2xl px-6 py-4 text-sm text-white focus:outline-none focus:border-indigo-500/50 transition-all placeholder:text-slate-700"
              value={formData.email}
              onChange={(e) => setFormData({...formData, email: e.target.value})}
              disabled={loading}
            />
            <input
              type="password"
              placeholder="Password"
              className="w-full bg-white/5 border border-white/5 rounded-2xl px-6 py-4 text-sm text-white focus:outline-none focus:border-indigo-500/50 transition-all placeholder:text-slate-700"
              value={formData.password}
              onChange={(e) => setFormData({...formData, password: e.target.value})}
              disabled={loading}
            />

            {error && <p className="text-rose-400 text-[10px] font-bold uppercase text-center tracking-wider">{error}</p>}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-5 rounded-2xl bg-gradient-to-r from-indigo-600 to-violet-600 text-[11px] font-bold uppercase tracking-[0.3em] shadow-xl shadow-indigo-600/30 hover:scale-[1.02] active:scale-95 transition-all text-white disabled:opacity-50 flex items-center justify-center gap-3"
            >
              {loading && <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
              {isLogin ? 'Initialize System' : 'Create Account'}
            </button>
          </form>

          <div className="mt-8 text-center">
            <button
              onClick={() => setIsLogin(!isLogin)}
              disabled={loading}
              className="text-[10px] text-slate-500 hover:text-indigo-400 font-bold uppercase tracking-widest transition-colors"
            >
              {isLogin ? "Don't have an account? Sign Up" : "Already registered? Login"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

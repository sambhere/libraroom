
import React, { useState, useRef, useEffect } from 'react';
import { LofiTrack } from '../types';

const LOFI_TRACKS: LofiTrack[] = [
  {
    id: 'bn-1',
    title: 'Deep Brown Noise',
    artist: 'Neural Ambient',
    url: 'https://actions.google.com/sounds/v1/water/rain_on_roof.ogg', // Reliable atmospheric source
    cover: 'https://picsum.photos/seed/static/400/400'
  },
  {
    id: '1',
    title: 'Study Session',
    artist: 'Lofi Girl',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    cover: 'https://picsum.photos/seed/study/400/400'
  },
  {
    id: '2',
    title: 'Moonlight Rain',
    artist: 'Cloudy Beats',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
    cover: 'https://picsum.photos/seed/rain/400/400'
  },
  {
    id: '3',
    title: 'Midnight Coffee',
    artist: 'Chillhop',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
    cover: 'https://picsum.photos/seed/coffee/400/400'
  },
  {
    id: '4',
    title: 'Cosmic Drift',
    artist: 'Lofi Panda',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3',
    cover: 'https://picsum.photos/seed/space/400/400'
  },
  {
    id: '5',
    title: 'Quiet Reflection',
    artist: 'Zen Vibes',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-15.mp3',
    cover: 'https://picsum.photos/seed/zen/400/400'
  }
];

export const MusicPlayer: React.FC = () => {
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const currentTrack = LOFI_TRACKS[currentTrackIndex];

  useEffect(() => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.play().catch(e => {
          console.warn('Playback blocked by browser policy', e);
          setIsPlaying(false);
        });
      } else {
        audioRef.current.pause();
      }
    }
  }, [isPlaying, currentTrackIndex]);

  const togglePlay = () => setIsPlaying(!isPlaying);
  const nextTrack = () => setCurrentTrackIndex((p) => (p + 1) % LOFI_TRACKS.length);
  const prevTrack = () => setCurrentTrackIndex((p) => (p - 1 + LOFI_TRACKS.length) % LOFI_TRACKS.length);

  return (
    <div className="flex flex-col h-full items-center justify-center space-y-10 py-2 animate-in fade-in duration-700">
      <div className="relative group">
        <div className={`absolute -inset-8 bg-indigo-500/10 rounded-full blur-3xl transition-opacity duration-1000 ${isPlaying ? 'opacity-100' : 'opacity-0'}`} />
        <div className={`relative w-48 h-48 rounded-[3rem] overflow-hidden border-4 border-white/5 shadow-2xl transition-all duration-[3s] ${isPlaying ? 'scale-105 rotate-12' : 'scale-100 rotate-0'}`}>
          <img src={currentTrack.cover} alt={currentTrack.title} className="w-full h-full object-cover" />
          {isPlaying && (
            <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
              <div className="flex gap-1.5 items-end h-12">
                <div className="w-1.5 bg-white/50 rounded-full animate-bounce [animation-duration:1s]" />
                <div className="w-1.5 bg-white/50 rounded-full animate-bounce [animation-duration:0.6s]" />
                <div className="w-1.5 bg-white/50 rounded-full animate-bounce [animation-duration:0.8s]" />
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="text-center z-10">
        <h2 className="text-xl font-bold text-white mb-1">{currentTrack.title}</h2>
        <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.3em]">{currentTrack.artist}</p>
      </div>

      <audio ref={audioRef} src={currentTrack.url} onEnded={nextTrack} />

      <div className="flex items-center gap-8 z-10">
        <button onClick={prevTrack} className="text-slate-600 hover:text-white transition-all"><svg className="w-7 h-7" fill="currentColor" viewBox="0 0 20 20"><path d="M8.445 14.832A1 1 0 0010 14V6a1 1 0 00-1.555-.832l-6 4a1 1 0 000 1.664l6 4zM14.445 14.832A1 1 0 0016 14V6a1 1 0 00-1.555-.832l-6 4a1 1 0 000 1.664l6 4z" /></svg></button>
        <button onClick={togglePlay} className="w-20 h-20 rounded-full bg-white text-slate-950 flex items-center justify-center shadow-2xl hover:scale-105 active:scale-95 transition-all">
          {isPlaying ? <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" /></svg> : <svg className="w-8 h-8 ml-1" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" /></svg>}
        </button>
        <button onClick={nextTrack} className="text-slate-600 hover:text-white transition-all"><svg className="w-7 h-7" fill="currentColor" viewBox="0 0 20 20"><path d="M4.555 5.168A1 1 0 003 6v8a1 1 0 001.555.832l6-4a1 1 0 000-1.664l-6-4zM11.555 5.168A1 1 0 0010 6v8a1 1 0 001.555.832l6-4a1 1 0 000-1.664l-6-4z" /></svg></button>
      </div>

      <div className="w-full max-w-sm bg-slate-900/40 rounded-3xl border border-white/5 overflow-hidden backdrop-blur-xl">
        {LOFI_TRACKS.map((track, idx) => (
          <button key={track.id} onClick={() => { setCurrentTrackIndex(idx); setIsPlaying(true); }} className={`w-full flex items-center gap-4 p-4 text-left border-b border-white/[0.02] last:border-none transition-all ${currentTrackIndex === idx ? 'bg-indigo-500/10' : 'hover:bg-white/[0.02]'}`}>
            <img src={track.cover} className="w-10 h-10 rounded-lg object-cover" alt="" />
            <div className="flex-1 overflow-hidden">
              <p className={`text-xs font-bold truncate ${currentTrackIndex === idx ? 'text-indigo-400' : 'text-slate-400'}`}>{track.title}</p>
              <p className="text-[9px] font-bold text-slate-600 uppercase tracking-tighter">{track.artist}</p>
            </div>
            {currentTrackIndex === idx && isPlaying && <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-ping" />}
          </button>
        ))}
      </div>
    </div>
  );
};

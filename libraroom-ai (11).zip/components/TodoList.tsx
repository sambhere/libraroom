import React, { useState, useEffect, useRef } from 'react';
import { Todo } from '../types';
import { dbService } from '../services/databaseService';

interface TodoListProps {
  userEmail: string;
}

export const TodoList: React.FC<TodoListProps> = ({ userEmail }) => {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [loading, setLoading] = useState(true);
  const [inputValue, setInputValue] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');
  const editInputRef = useRef<HTMLInputElement>(null);

  // Initial Load from DB
  useEffect(() => {
    const loadTasks = async () => {
      setLoading(true);
      const data = await dbService.getTasks(userEmail);
      setTodos(data);
      setLoading(false);
    };
    loadTasks();
  }, [userEmail]);

  // Debounced Sync to Cloud
  useEffect(() => {
    if (loading) return;
    
    // Immediate local persistence
    localStorage.setItem(`libraroom_todos_${userEmail}`, JSON.stringify(todos));

    // Debounce cloud sync
    const timeout = setTimeout(() => {
      dbService.saveTasks(userEmail, todos);
    }, 1000);

    return () => clearTimeout(timeout);
  }, [todos, userEmail, loading]);

  useEffect(() => {
    if (editingId && editInputRef.current) {
      editInputRef.current.focus();
    }
  }, [editingId]);

  const addTodo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;
    const newTodo: Todo = {
      id: Date.now().toString(),
      text: inputValue,
      completed: false,
      createdAt: Date.now(),
    };
    setTodos([newTodo, ...todos]);
    setInputValue('');
  };

  const toggleTodo = (id: string) => {
    setTodos(todos.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const deleteTodo = (id: string) => {
    setTodos(todos.filter(t => t.id !== id));
  };

  const startEditing = (todo: Todo) => {
    setEditingId(todo.id);
    setEditValue(todo.text);
  };

  const saveEdit = () => {
    if (!editingId) return;
    if (!editValue.trim()) {
      setEditingId(null);
      return;
    }
    setTodos(todos.map(t => t.id === editingId ? { ...t, text: editValue.trim() } : t));
    setEditingId(null);
  };

  const handleEditKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') saveEdit();
    if (e.key === 'Escape') setEditingId(null);
  };

  const clearCompleted = () => {
    setTodos(todos.filter(t => !t.completed));
  };

  const activeCount = todos.filter(t => !t.completed).length;

  return (
    <div className="flex flex-col h-full space-y-6 animate-in fade-in duration-500">
      <div className="flex justify-between items-center px-1">
        <div className="flex flex-col whitespace-nowrap">
          <h2 className="text-lg font-bold text-white tracking-tight">Today's Agenda</h2>
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">
            {loading ? 'Fetching Neural Data...' : `${activeCount} Pending Tasks`}
          </span>
        </div>
        {todos.some(t => t.completed) && (
          <button onClick={clearCompleted} className="px-3 py-1 rounded-lg bg-rose-500/10 text-[10px] font-bold text-rose-400 hover:bg-rose-500/20 transition-all uppercase tracking-widest border border-rose-500/20 whitespace-nowrap">
            Clear Finished
          </button>
        )}
      </div>

      <form onSubmit={addTodo} className="relative group">
        <div className="absolute -inset-1 bg-gradient-to-r from-indigo-500/20 to-purple-500/20 rounded-2xl blur opacity-0 group-focus-within:opacity-100 transition-opacity" />
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="What needs to be done?"
          className="relative w-full bg-slate-900/60 backdrop-blur-xl border border-white/5 rounded-2xl px-6 py-4 pr-14 text-sm text-slate-200 focus:outline-none focus:border-indigo-500/50 transition-all placeholder:text-slate-700"
        />
        <button
          type="submit"
          className="absolute right-3 top-3 w-10 h-10 bg-indigo-500 rounded-xl text-white shadow-lg shadow-indigo-500/30 hover:scale-105 active:scale-95 transition-all flex items-center justify-center z-10"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 4v16m8-8H4" />
          </svg>
        </button>
      </form>

      <div className="flex-1 overflow-y-auto space-y-3 pb-4 pr-1">
        {loading ? (
           <div className="flex flex-col items-center justify-center py-20 opacity-20">
             <div className="w-8 h-8 border-4 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin mb-4" />
             <p className="text-xs font-bold uppercase tracking-widest">Accessing Neon Cloud</p>
           </div>
        ) : todos.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 opacity-30 grayscale text-slate-500">
            <svg className="w-16 h-16 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>
            <p className="text-sm font-medium tracking-wide">Nothing on the radar.</p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {todos.map((todo) => (
              <div
                key={todo.id}
                className={`group flex items-center gap-4 p-4 rounded-2xl transition-all duration-300 border ${
                  todo.completed 
                    ? 'bg-slate-900/20 border-white/5 opacity-50 shadow-inner' 
                    : 'bg-slate-900/60 border-white/5 hover:border-indigo-500/20 hover:bg-slate-900/80'
                }`}
              >
                <button
                  onClick={() => toggleTodo(todo.id)}
                  className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-all shrink-0 ${
                    todo.completed 
                      ? 'bg-indigo-500 border-indigo-500 text-white shadow-lg shadow-indigo-500/20' 
                      : 'border-slate-700 hover:border-indigo-400'
                  }`}
                >
                  {todo.completed && <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>}
                </button>

                <div className="flex-1 overflow-hidden">
                  {editingId === todo.id ? (
                    <input
                      ref={editInputRef}
                      type="text"
                      value={editValue}
                      onChange={(e) => setEditValue(e.target.value)}
                      onBlur={saveEdit}
                      onKeyDown={handleEditKeyDown}
                      className="w-full bg-indigo-500/10 border border-indigo-500/50 rounded-lg px-2 py-1 text-sm text-white focus:outline-none"
                    />
                  ) : (
                    <span 
                      className={`text-sm font-medium leading-relaxed block truncate transition-all duration-300 ${todo.completed ? 'line-through text-slate-600' : 'text-slate-200'}`}
                    >
                      {todo.text}
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-1 shrink-0 opacity-0 group-hover:opacity-100 transition-all translate-x-2 group-hover:translate-x-0">
                  {!todo.completed && editingId !== todo.id && (
                    <button
                      onClick={() => startEditing(todo)}
                      className="p-2 text-slate-500 hover:text-indigo-400 hover:bg-indigo-400/10 rounded-xl transition-all"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                      </svg>
                    </button>
                  )}
                  <button
                    onClick={() => deleteTodo(todo.id)}
                    className="p-2 text-slate-700 hover:text-rose-400 hover:bg-rose-400/10 rounded-xl transition-all"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

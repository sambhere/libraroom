
import React, { useState, useRef, useEffect } from 'react';
import { createAIChatSession } from '../services/geminiService';
import { dbService } from '../services/databaseService';
import { ChatMessage } from '../types';

interface NeuralAIStudioProps {
  userEmail: string;
}

export const NeuralAIStudio: React.FC<NeuralAIStudioProps> = ({ userEmail }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [isInitialLoading, setIsInitialLoading] = useState(true);
  const [isListening, setIsListening] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  
  const [customInstruction, setCustomInstruction] = useState(() => {
    return localStorage.getItem('libraroom_ai_instruction') || '';
  });

  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);
  const chatSessionRef = useRef<any>(null);

  useEffect(() => {
    const loadHistory = async () => {
      try {
        setIsInitialLoading(true);
        const history = await dbService.getChatMessages(userEmail);
        
        if (history && history.length > 0) {
          setMessages(history);
        } else {
          setMessages([{ 
            id: 'welcome',
            role: 'ai', 
            text: 'Neural connection established. I am synced with your workspace. How can I assist your productivity today? ✨',
            createdAt: Date.now()
          }]);
        }
        
        chatSessionRef.current = createAIChatSession();
      } catch (err) {
        console.error("AI Studio Init Error:", err);
      } finally {
        setIsInitialLoading(false);
        setTimeout(() => inputRef.current?.focus(), 500);
      }
    };
    
    loadHistory();
  }, [userEmail]);

  useEffect(() => {
    if (isInitialLoading || messages.length === 0) return;
    const timeout = setTimeout(() => {
      dbService.saveChatMessages(userEmail, messages);
    }, 2000);
    return () => clearTimeout(timeout);
  }, [messages, userEmail, isInitialLoading]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
    }
  }, [messages, loading]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: input.trim(),
      createdAt: Date.now()
    };

    setInput('');
    setMessages(prev => [...prev, userMessage]);
    setLoading(true);

    try {
      // Ensure session exists
      if (!chatSessionRef.current) chatSessionRef.current = createAIChatSession();
      
      const result = await chatSessionRef.current.sendMessage({ message: userMessage.text });
      
      setMessages(prev => [...prev, {
        id: `ai-${Date.now()}`,
        role: 'ai',
        text: result.text || "Neural flicker. Please retry your query.",
        createdAt: Date.now()
      }]);
    } catch (err: any) {
      setMessages(prev => [...prev, {
        id: `err-${Date.now()}`,
        role: 'ai',
        text: `Neural matrix unstable: ${err.message || "Check your network or API key configuration."} ☁️`,
        createdAt: Date.now()
      }]);
    } finally {
      setLoading(false);
    }
  };

  const toggleListening = () => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) return alert("Speech recognition unsupported in this environment.");
    if (isListening) { recognitionRef.current?.stop(); return; }
    const rec = new SR();
    rec.onstart = () => setIsListening(true);
    rec.onresult = (e: any) => setInput(p => p + ' ' + e.results[0][0].transcript);
    rec.onend = () => setIsListening(false);
    recognitionRef.current = rec;
    rec.start();
  };

  const handleUpdateInstruction = (val: string) => {
    setCustomInstruction(val);
    localStorage.setItem('libraroom_ai_instruction', val);
    chatSessionRef.current = createAIChatSession(); 
  };

  if (isInitialLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-full py-32 opacity-30">
        <div className="w-10 h-10 border-4 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin mb-6" />
        <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-indigo-400">Syncing Neural Memory...</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full gap-5 animate-in fade-in duration-500 overflow-hidden relative min-h-[500px]">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-2">
           <div className={`w-2 h-2 rounded-full ${loading ? 'bg-amber-500 animate-pulse' : 'bg-indigo-500'} shadow-[0_0_8px_rgba(99,102,241,0.5)]`} />
           <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">
             {loading ? 'Neural Processing...' : 'Neural Link: Secure'}
           </span>
        </div>
        <button onClick={() => setShowSettings(!showSettings)} className={`p-2 rounded-xl transition-all ${showSettings ? 'bg-indigo-500 text-white' : 'bg-white/5 text-slate-500 hover:text-white'}`}>
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924-1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37a1.724 1.724 0 002.572-1.065z" /></svg>
        </button>
      </div>

      {showSettings && (
        <div className="p-6 rounded-3xl bg-indigo-500/5 border border-indigo-500/10 animate-in slide-in-from-top-4">
          <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest mb-3">Neural Tuning</p>
          <textarea 
            value={customInstruction}
            onChange={(e) => handleUpdateInstruction(e.target.value)}
            placeholder="Change how I think or speak..."
            className="w-full bg-slate-950/50 border border-white/5 rounded-2xl p-4 text-xs text-slate-300 focus:outline-none focus:border-indigo-500/40 resize-none h-24"
          />
          <button onClick={() => setShowSettings(false)} className="mt-3 w-full py-2 bg-indigo-500/10 rounded-xl text-[9px] font-bold uppercase tracking-widest text-indigo-400">Apply Set</button>
        </div>
      )}

      <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-6 pr-2 py-2 custom-scrollbar">
        {messages.map((m) => (
          <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2`}>
            <div className={`max-w-[85%] px-5 py-4 rounded-3xl text-sm leading-relaxed ${
              m.role === 'user' ? 'bg-indigo-600 text-white rounded-tr-none shadow-lg shadow-indigo-500/10' : 'bg-slate-900/60 border border-white/5 text-slate-200 rounded-tl-none backdrop-blur-md'
            }`}>
              {m.text}
            </div>
          </div>
        ))}
        {loading && <div className="flex gap-1.5 p-4 bg-white/5 rounded-2xl w-max animate-pulse"><div className="w-1.5 h-1.5 bg-indigo-500 rounded-full" /><div className="w-1.5 h-1.5 bg-indigo-500 rounded-full" /><div className="w-1.5 h-1.5 bg-indigo-500 rounded-full" /></div>}
      </div>

      <form onSubmit={handleSubmit} className="relative mt-auto pb-4">
        <div className="relative flex items-center bg-slate-950 border border-white/10 rounded-full focus-within:border-indigo-500/50 transition-all shadow-2xl">
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={isListening ? "Listening..." : "Query Neural Hub..."}
            className="w-full bg-transparent px-8 py-5 pr-24 text-sm focus:outline-none text-slate-200"
            autoComplete="off"
          />
          <div className="absolute right-2 flex gap-1.5">
            <button type="button" onClick={toggleListening} className={`w-10 h-10 rounded-full flex items-center justify-center ${isListening ? 'bg-rose-500 text-white' : 'text-slate-500 hover:text-white'}`}><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg></button>
            <button type="submit" disabled={loading || !input.trim()} className="w-10 h-10 bg-indigo-600 rounded-full text-white disabled:opacity-20 flex items-center justify-center hover:bg-indigo-500 transition-colors shadow-lg"><svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" /></svg></button>
          </div>
        </div>
      </form>
    </div>
  );
};

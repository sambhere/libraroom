import React from 'react';

interface LandingPageProps {
  onStart: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onStart }) => {
  return (
    <main className="min-h-screen relative overflow-hidden flex flex-col bg-[#020617] text-slate-200">
      {/* Dynamic Neural Background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-indigo-600/20 blur-[150px] rounded-full animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-violet-600/10 blur-[150px] rounded-full" />
      </div>

      {/* Navigation Branding */}
      <nav className="relative z-10 w-full px-8 py-10 flex justify-between items-center max-w-7xl mx-auto">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <span className="font-bold text-white text-xl italic tracking-tighter">L</span>
          </div>
          <span className="text-xl font-bold tracking-tight text-white">Libraroom AI</span>
        </div>
        {/* Hidden on mobile to ensure responsiveness */}
        <div className="hidden sm:flex items-center gap-4">
          <button 
            onClick={onStart} 
            className="px-6 py-3 rounded-xl bg-white/5 border border-white/10 text-[10px] font-bold uppercase tracking-widest hover:bg-white/10 hover:border-white/20 transition-all text-slate-300"
          >
            Register/Login
          </button>
        </div>
      </nav>

      {/* Hero Content */}
      <section className="relative z-10 flex-1 flex flex-col items-center justify-center px-6 py-20 text-center max-w-4xl mx-auto">
        <div className="mb-6 px-4 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 inline-block animate-bounce">
          <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-[0.2em]">AI Powered Workspace</span>
        </div>
        
        <h1 className="text-5xl sm:text-7xl font-extrabold text-white tracking-tight mb-8 leading-[1.1]">
          Elevate Your <br />
          <span className="bg-gradient-to-r from-indigo-400 via-violet-400 to-indigo-400 bg-clip-text text-transparent">Cognitive Flow</span>
        </h1>
        
        <p className="text-lg sm:text-xl text-slate-400 font-medium mb-12 max-w-2xl leading-relaxed">
          Libraroom AI is your all in one AI powered workspace built for speed, clarity, and results. It helps you write, research, summarize, brainstorm, and build ideas without wasting time switching tools.
        </p>

        <div className="flex flex-col sm:flex-row items-center gap-10 sm:gap-12">
          <div className="flex flex-col items-center gap-3">
            <button
              onClick={onStart}
              aria-label="Get started with Libraroom AI"
              className="px-12 py-5 rounded-full bg-indigo-600 text-white font-bold text-xs uppercase tracking-[0.3em] shadow-2xl shadow-indigo-600/30 hover:scale-105 active:scale-95 transition-all group overflow-hidden relative"
            >
              <span className="relative z-10">Get Started</span>
              <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 to-violet-500 opacity-0 group-hover:opacity-100 transition-opacity" />
            </button>
            <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-[0.2em] neon-text-indigo animate-pulse">It's completely free!</p>
          </div>
          
          <div className="flex items-center gap-4 text-slate-500">
             <div className="flex -space-x-3">
               {[1,2,3].map(i => (
                 <img key={i} className="w-8 h-8 rounded-full border-2 border-[#020617]" src={`https://api.dicebear.com/7.x/bottts/svg?seed=${i}focus`} alt="user" />
               ))}
             </div>
             <span className="text-[10px] font-bold uppercase tracking-widest">Joined by 2k+ Students</span>
          </div>
        </div>
      </section>

      {/* Main Features Heading */}
      <section className="relative z-10 pt-20 pb-10 text-center">
        <h2 className="text-sm font-black uppercase tracking-[0.5em] text-slate-500 inline-block relative">
          Main Features
          <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 w-12 h-1 bg-gradient-to-r from-indigo-500 to-violet-500 rounded-full" />
        </h2>
      </section>

      {/* Feature Grid Showcase */}
      <section id="features" className="relative z-10 px-6 py-24 bg-slate-950/20">
        <div className="max-w-7xl mx-auto flex flex-wrap justify-center gap-8">
          
          <div className="w-full md:w-[calc(50%-1rem)] lg:w-[calc(33.33%-1.5rem)] p-8 rounded-[2.5rem] bg-white/[0.02] border border-white/5 backdrop-blur-3xl hover:border-indigo-500/20 transition-all group">
            <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 flex items-center justify-center text-indigo-400 mb-6 group-hover:scale-110 transition-transform">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
            </div>
            <h3 className="text-xl font-bold text-white mb-3">Neural Study Vault</h3>
            <p className="text-sm text-slate-500 leading-relaxed font-medium">Let AI clean your notes, summarize long lectures, and help you think better in one focused workspace.</p>
          </div>

          <div className="w-full md:w-[calc(50%-1rem)] lg:w-[calc(33.33%-1.5rem)] p-8 rounded-[2.5rem] bg-white/[0.02] border border-white/5 backdrop-blur-3xl hover:border-violet-500/20 transition-all group">
            <div className="w-12 h-12 rounded-2xl bg-violet-500/10 flex items-center justify-center text-violet-400 mb-6 group-hover:scale-110 transition-transform">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            </div>
            <h3 className="text-xl font-bold text-white mb-3">Deep Focus Matrix</h3>
            <p className="text-sm text-slate-500 leading-relaxed font-medium">Calibrated Pomodoro techniques with real-time session tracking designed to trigger flow states and maintain peak mental endurance.</p>
          </div>

          <div className="w-full md:w-[calc(50%-1rem)] lg:w-[calc(33.33%-1.5rem)] p-8 rounded-[2.5rem] bg-white/[0.02] border border-white/5 backdrop-blur-3xl hover:border-emerald-500/20 transition-all group">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 flex items-center justify-center text-emerald-400 mb-6 group-hover:scale-110 transition-transform">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" /></svg>
            </div>
            <h3 className="text-xl font-bold text-white mb-3">Aural Atmosphere</h3>
            <p className="text-sm text-slate-500 leading-relaxed font-medium">A curated selection of lofi beats and ambient soundscapes to anchor your mind in the present moment, wherever you are.</p>
          </div>

          <div className="w-full md:w-[calc(50%-1rem)] lg:w-[calc(33.33%-1.5rem)] p-8 rounded-[2.5rem] bg-white/[0.02] border border-white/5 backdrop-blur-3xl hover:border-rose-500/20 transition-all group">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/10 flex items-center justify-center text-rose-400 mb-6 group-hover:scale-110 transition-transform">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" /></svg>
            </div>
            <h3 className="text-xl font-bold text-white mb-3">Task Orchestrator</h3>
            <p className="text-sm text-slate-500 leading-relaxed font-medium">Manage complex deadlines with a clean, high-performance agenda designed to maintain cognitive clarity throughout the day.</p>
          </div>

          <div className="w-full md:w-[calc(50%-1rem)] lg:w-[calc(33.33%-1.5rem)] p-8 rounded-[2.5rem] bg-white/[0.02] border border-white/5 backdrop-blur-3xl hover:border-sky-500/20 transition-all group">
            <div className="w-12 h-12 rounded-2xl bg-sky-500/10 flex items-center justify-center text-sky-400 mb-6 group-hover:scale-110 transition-transform">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z" /></svg>
            </div>
            <h3 className="text-xl font-bold text-white mb-3">Secure Neural Sync</h3>
            <p className="text-sm text-slate-500 leading-relaxed font-medium">Your progress is mirrored across all devices in real-time via enterprise-grade encrypted cloud architecture powered by Neon.</p>
          </div>
        </div>
      </section>

      {/* Why Libraroom AI Section */}
      <section className="relative z-10 px-6 py-32 bg-slate-900/10 border-y border-white/5">
        <div className="max-w-5xl mx-auto text-center">
          <h2 className="text-4xl font-extrabold text-white mb-6">Why Libraroom AI?</h2>
          <p className="text-lg text-slate-400 mb-16 max-w-2xl mx-auto">What makes us different is our obsession with the student experience. We don't just provide tools; we build a sanctuary for your mind.</p>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="space-y-3">
              <p className="text-2xl font-black text-indigo-400">Speed</p>
              <p className="text-[10px] font-bold text-slate-600 uppercase tracking-widest">Instant Feedback</p>
            </div>
            <div className="space-y-3">
              <p className="text-2xl font-black text-violet-400">Simplicity</p>
              <p className="text-[10px] font-bold text-slate-600 uppercase tracking-widest">Zero Bloat</p>
            </div>
            <div className="space-y-3">
              <p className="text-2xl font-black text-emerald-400">Privacy</p>
              <p className="text-[10px] font-bold text-slate-600 uppercase tracking-widest">Encrypted Sync</p>
            </div>
            <div className="space-y-3">
              <p className="text-2xl font-black text-rose-400">Unified</p>
              <p className="text-[10px] font-bold text-slate-600 uppercase tracking-widest">All in One</p>
            </div>
          </div>
        </div>
      </section>

      {/* Secondary Call to Action - Updated for "Live" status */}
      <section className="relative z-10 px-6 py-32 overflow-hidden">
        <div className="absolute inset-0 bg-indigo-600/5 blur-[120px]" />
        <div className="max-w-4xl mx-auto rounded-[3rem] bg-white/[0.02] border border-white/5 p-12 sm:p-20 text-center backdrop-blur-3xl relative overflow-hidden">
           <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-3xl -mr-16 -mt-16" />
           <h3 className="text-3xl sm:text-4xl font-bold text-white mb-6 tracking-tight">Ready to transform your study game?</h3>
           <p className="text-slate-400 mb-10 text-lg">Start building smarter today. Experience the future of cognitive productivity and enter your peak performance state instantly.</p>
           <button 
             onClick={onStart}
             className="px-10 py-5 rounded-2xl bg-white text-slate-950 font-black text-xs uppercase tracking-[0.3em] hover:scale-105 active:scale-95 transition-all shadow-2xl shadow-white/10"
           >
             Get Started for Free
           </button>
        </div>
      </section>

      {/* Bottom CTA Branding */}
      <footer className="relative z-10 px-8 py-16 text-center border-t border-white/5 max-w-7xl mx-auto w-full">
        <div className="flex flex-col items-center gap-6">
          <div className="space-y-2">
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">
              © 2026 Libraroom AI. All rights reserved.
            </p>
            <p className="text-[9px] font-medium text-slate-600 max-w-lg mx-auto leading-relaxed">
              All content, features, and designs are protected by applicable copyright and intellectual property laws.
            </p>
          </div>
          
          <div className="h-px w-8 bg-white/5" />
          
          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.4em]">
            Developed by <a 
              href="https://pk.linkedin.com/in/sambinc" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="text-indigo-400 hover:text-indigo-300 transition-colors underline underline-offset-4 decoration-indigo-500/30"
            >
              SAMB Inc.
            </a>
          </p>
        </div>
      </footer>
    </main>
  );
};
